# GEONARA — User-Facing MVP Prototype 1.0

## What this is
A self-contained, browser-based interactive prototype designed for an end-user walkthrough. It is intentionally usable without installation, a server, an API key, or an internet connection.

## Run it
1. Extract the ZIP archive.
2. Open `frontend/index.html` in a current version of Chrome, Edge, or Firefox.
3. Create a demo account with a name, email, and a demo-only password (at least 6 characters).
4. Explore Overview, Dictionary, Research, GEONARA AI, Messages, and My Profile.

You can also open the standalone `GEONARA_User_Facing_MVP_v1.0.html` supplied separately.

## Included interactions
- Demo sign-up and sign-in, with account state held in this browser.
- Searchable geological dictionary with discipline filtering.
- Searchable sample research catalogue with topic and year filters.
- Save/unsave sample research records.
- Rule-based GEONARA AI interaction for a small set of geology topics.
- Editable local profile.
- Local test messaging with sample contacts.
- Reset local demo data.

## Important technical boundary
This is a front-end demonstration, not a production service:
- Authentication is simulated and credentials are stored locally in the browser. Do not use a real password or sensitive information.
- Profile changes, saved records, and messages remain in the same browser's local storage. No other user can see them.
- Research records are illustrative placeholders, not verified papers. No OpenAlex, Crossref, or Zenodo integration is connected.
- GEONARA AI is rule-based demo logic. No external AI model, RAG pipeline, or scientific source retrieval is connected.
- Sample messaging is local simulation. There is no server, WebSocket, delivery to real users, moderation system, or push notification.
- No production database, email verification, cloud file storage, analytics, or deployment configuration is included.

## Relationship to the supplied backend code
The supplied Python file contains a minimal FastAPI application with a root route and `/health` route, plus CORS configured with wildcard origins. It does not currently expose authentication, dictionary, research, AI, profile, or messaging APIs. The prototype therefore runs independently in the browser and does not pretend to connect to those missing APIs.

A small backend starter is included under `backend/` as a clean next-step scaffold. It is not required to run the browser prototype.

## Suggested next engineering milestone
Replace local demo persistence with FastAPI endpoints and a PostgreSQL database, then implement authentication and authorization before connecting user profiles and messaging. Add research providers and an AI provider only after API keys, licensing, privacy, and operating-cost decisions are approved.
