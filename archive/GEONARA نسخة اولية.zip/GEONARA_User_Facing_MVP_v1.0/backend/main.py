from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(
    title="GEONARA API",
    version="0.1.0",
    description="Development scaffold for the GEONARA platform.",
)

# Development-only origins. Replace with the exact deployed frontend origin(s).
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5500", "http://127.0.0.1:5500"],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
    allow_headers=["Authorization", "Content-Type"],
)

@app.get("/", tags=["Root"])
def root():
    return {"message": "GEONARA API development scaffold"}

@app.get("/health", tags=["Health"])
def health():
    return {"status": "ok", "service": "GEONARA API", "version": "0.1.0"}

@app.get("/api/v1/status", tags=["System"])
def api_status():
    return {
        "api_version": "v1",
        "modules": {
            "authentication": "not_implemented",
            "dictionary": "not_implemented",
            "research": "not_implemented",
            "ai": "not_implemented",
            "profiles": "not_implemented",
            "messaging": "not_implemented",
        },
    }
